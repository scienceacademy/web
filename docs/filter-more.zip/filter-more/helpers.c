#include "helpers.h"

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    return;
}

// Pixalate image
void pixelate(int height, int width, RGBTRIPLE image[height][width])
{
    return;
}

// Apply a vignette effect
void vignette(int height, int width, RGBTRIPLE image[height][width])
{
    return;
}

// Detect edges
void edges(int height, int width, RGBTRIPLE image[height][width])
{
    return;
}
