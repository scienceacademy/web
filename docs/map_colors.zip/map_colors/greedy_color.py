import random
import us_map

colors = [
	"white",
	"cornflowerblue",
	"goldenrod",
	"paleturquoise",
	"mediumseagreen",
	"lightcoral",
	"orchid"
]

state_names = [
    "Alabama", "Arizona", "Arkansas", "California", "Colorado",
    "Connecticut", "Delaware", "Florida", "Georgia", "Idaho",
    "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana",
    "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota",
    "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada",
    "New Hampshire", "New Jersey", "New Mexico", "New York",
    "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon",
    "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota",
    "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington",
    "West Virginia", "Wisconsin", "Wyoming"
]

graph = {
    0: [7, 8, 21, 39],
    1: [3, 28, 25, 41],
    2: [19, 33, 40, 15, 21, 39],
    3: [1, 25, 34],
    4: [47, 41, 28, 33, 13, 24],
    5: [36, 18, 29],
    6: [27, 17, 35],
    7: [0, 8],
    8: [7, 0, 37, 30, 39],
    9: [44, 34, 25, 41, 47, 23],
    10: [46, 12, 22, 14, 11],
    11: [10, 14, 32, 19],
    12: [23, 38, 24, 22, 10, 46],
    13: [24, 4, 33, 22],
    14: [32, 11, 10, 22, 39, 43, 45],
    15: [40, 2, 21],
    16: [26],
    17: [6, 35, 45, 43],
    18: [36, 5, 29, 26, 42],
    19: [32, 11, 46],
    20: [31, 38, 12, 46],
    21: [0, 39, 2, 15],
    22: [12, 24, 13, 33, 2, 39, 14, 10],
    23: [9, 47, 31, 38],
    24: [38, 47, 4, 13, 22, 12],
    25: [3, 1, 41, 9, 34],
    26: [16, 42, 18],
    27: [29, 35, 6],
    28: [1, 40, 33, 4],
    29: [35, 27, 5, 18, 42],
    30: [43, 39, 8, 37],
    31: [23, 38, 19],
    32: [19, 11, 14, 45, 35],
    33: [4, 13, 22, 2, 40, 28],
    34: [3, 25, 9, 44],
    35: [29, 27, 6, 17, 45, 32],
    36: [18, 5],
    37: [30, 8],
    38: [31, 20, 12, 24, 47, 23],
    39: [14, 43, 30, 8, 0, 21, 2, 22],
    40: [28, 33, 2, 15],
    41: [9, 47, 4, 1, 25],
    42: [26, 18, 29],
    43: [17, 45, 14, 39, 30],
    44: [9, 34],
    45: [32, 35, 18, 43, 14],
    46: [19, 10, 12, 19],
    47: [23, 38, 24, 4, 41, 9]
}

# TODO
# Using the greedy coloring algorithm, color each state.
# Result should be a dictionary of "state name" : color_index
map_colors = {}

# calling this function with your dictionary will produce
# a colored map image called "us_map.png"
us_map.create_map(map_colors, colors)