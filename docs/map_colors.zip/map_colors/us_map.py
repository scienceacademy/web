import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap
from matplotlib.patches import Polygon


def create_map(map_colors, color_list):
    # create a png map using US geo data
    # Inputs:
    # map_colors: a dictionary of statenames(strings) : colors (integers)
    # color_list: an array of color names. See https://matplotlib.org/stable/gallery/color/named_colors.html
    map = Basemap(llcrnrlon=-119, llcrnrlat=22, urcrnrlon=-64, urcrnrlat=49,
                  projection='lcc', lat_1=33, lat_2=45, lon_0=-95)

    # load the shapefile, use the name 'states'
    map.readshapefile('st99_d00', name='states', drawbounds=True)

    shp_info = map.readshapefile('st99_d00', 'states', drawbounds=True,
                               linewidth=0.45, color='gray')

    ax = plt.gca()  # get current axes instance

    # Only include the 48 contiguous states
    skip_states = ["District of Columbia", "Puerto Rico", "Alaska", "Hawaii"]
    states= []
    colors = {}

    for shapedict in map.states_info:
        statename = shapedict["NAME"]
        if statename not in skip_states:
            colors[statename] = "red"
        states.append(statename)

    for nshape,seg in enumerate(map.states):
        if states[nshape] not in skip_states:
            color = color_list[map_colors[states[nshape]]]
            poly = Polygon(seg, facecolor=color, edgecolor=color)
            ax.add_patch(poly)

    plt.savefig("us_map.png")
