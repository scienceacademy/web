import matplotlib.pyplot as plt
from sklearn.datasets import fetch_openml
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, classification_report
from time import time

# Load MNIST dataset
mnist = fetch_openml("mnist_784", parser="auto")
X, y = mnist.data, mnist.target

# Split data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Scale data (important for neural networks)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# ADJUSTMENTS
neuron_layers = (50, )
iterations = 20
learning_rate = 0.1
alpha = 1e-4

# Create a neural network model
mlp = MLPClassifier(
    hidden_layer_sizes=neuron_layers,
    max_iter=iterations,
    alpha=alpha,
    solver="sgd",
    verbose=True,
    random_state=1,
    learning_rate_init=learning_rate,
)

start_time = time()
# Train the model
mlp.fit(X_train, y_train)
print(f"Training set score: {mlp.score(X_train, y_train):.4f}")
print(f"Test set score: {mlp.score(X_test, y_test):.4f}")
duration = time() - start_time
print(f"Training time: {duration:.2f}s")

# Evaluate the model
predictions = mlp.predict(X_test)
accuracy = accuracy_score(y_test, predictions)
print(f"Test Accuracy: {accuracy*100:.2f}%")
# print(classification_report(y_test, predictions))

# Visualizing some predictions
fig, axes = plt.subplots(4, 5, figsize=(15, 4))
sample_images = X_test[:20]  # Selecting the first 10 images
sample_labels = y_test[:20]  # Selecting the first 10 labels
sample_predictions = predictions[:20]  # Selecting the first 10 predictions

for i, ax in enumerate(axes.ravel()):
    ax.imshow(sample_images[i].reshape(28, 28), cmap="gray")
    ax.set_title(f"Predicted: {sample_predictions[i]}, True: {sample_labels.iloc[i]}")
plt.tight_layout()
plt.show()
